package com.test.palindrome.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.test.palindrome.exception.PalindromeException;

@ControllerAdvice
public class ExceptionController{
	
	
}
