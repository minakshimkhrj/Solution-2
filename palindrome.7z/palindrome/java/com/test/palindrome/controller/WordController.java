package com.test.palindrome.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.test.palindrome.PalindromeImpl;
import com.test.palindrome.exception.PalindromeException;
import com.test.palindrome.model.Sentence;
import com.test.palindrome.model.Word;
import com.test.palindrome.repositories.WordRepository;

@RestController
public class WordController {
	
	@Autowired
	public WordRepository wordRepository;
	@Autowired
	public PalindromeImpl palindromeImpl;
	
	@GetMapping(value = "/getAllWords")
	public List<Word> getAllWords(){		
		return wordRepository.findAll();		
	}
	
	@PostMapping(value = "/sendString")
	public String addWord(@RequestBody Sentence sentence) {
		Word word = palindromeImpl.findLongestPalindrome(sentence);
		Word insertedWord = wordRepository.insert(word);
		return insertedWord.getValue();		
	}
	

}
