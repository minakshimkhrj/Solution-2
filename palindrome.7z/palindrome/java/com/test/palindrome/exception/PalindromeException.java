package com.test.palindrome.exception;

public class PalindromeException extends RuntimeException{
	private static final long SERIAL_LONG_UID = 1L;
}
