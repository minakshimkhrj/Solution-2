package com.test.palindrome.model;

import org.springframework.stereotype.Component;

@Component
public class Sentence {
	
	private String value;

	public Sentence() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Sentence(String value) {
		super();
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	

}
