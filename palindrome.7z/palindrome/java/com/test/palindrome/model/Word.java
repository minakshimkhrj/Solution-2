package com.test.palindrome.model;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.stereotype.Component;

@Document(collection = "words")
@Component
public class Word {


	private String value;
	
	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Word() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Word(String value, String length) {
		super();
		this.value = value;
	}
	
}
